package ru.hexatime.optimizer;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Item;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashSet;
import java.util.Set;

final class ItemCleaner {

    private final HexaOptimizer plugin;
    private BukkitTask task;
    private int left;
    private int interval;
    private Set<Integer> warnings = new HashSet<>();
    private final Set<Material> keep = new HashSet<>();

    ItemCleaner(HexaOptimizer plugin) {
        this.plugin = plugin;
    }

    void restart() {
        stop();
        var cfg = plugin.getConfig();
        if (!cfg.getBoolean("item-cleaner.enabled", true)) return;

        interval = Math.max(1, cfg.getInt("item-cleaner.interval-minutes", 30)) * 60;
        warnings = new HashSet<>(cfg.getIntegerList("item-cleaner.warnings-seconds"));
        keep.clear();
        for (String name : cfg.getStringList("item-cleaner.keep-items")) {
            Material m = Material.matchMaterial(name);
            if (m != null) keep.add(m);
        }
        left = interval;
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    void stop() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }

    private void tick() {
        left--;
        if (warnings.contains(left)) {
            plugin.broadcast("clear-warning", "seconds", String.valueOf(left));
        }
        if (left <= 0) {
            int n = clearNow();
            plugin.broadcast("cleared", "count", String.valueOf(n));
            left = interval;
        }
    }

    int clearNow() {
        int count = 0;
        for (World w : Bukkit.getWorlds()) {
            for (Item item : w.getEntitiesByClass(Item.class)) {
                if (keep.contains(item.getItemStack().getType())) continue;
                item.remove();
                count++;
            }
        }
        return count;
    }
}
