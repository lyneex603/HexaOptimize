package ru.hexatime.optimizer;

import org.bukkit.Chunk;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.entity.ItemSpawnEvent;

import java.util.EnumSet;
import java.util.Set;

final class SpawnLimiter implements Listener {

    private final HexaOptimizer plugin;
    private boolean enabled;
    private int maxMobs;
    private int maxSame;
    private int maxItems;
    private final Set<SpawnReason> ignored = EnumSet.noneOf(SpawnReason.class);

    SpawnLimiter(HexaOptimizer plugin) {
        this.plugin = plugin;
    }

    void load() {
        var cfg = plugin.getConfig();
        enabled = cfg.getBoolean("limits.enabled", true);
        maxMobs = cfg.getInt("limits.max-mobs-per-chunk", 40);
        maxSame = cfg.getInt("limits.max-same-type-per-chunk", 20);
        maxItems = cfg.getInt("limits.max-items-per-chunk", 100);
        ignored.clear();
        for (String name : cfg.getStringList("limits.ignore-spawn-reasons")) {
            try {
                ignored.add(SpawnReason.valueOf(name.toUpperCase()));
            } catch (IllegalArgumentException ignoredEx) {
                plugin.getLogger().warning("Неизвестная причина спавна: " + name);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMobSpawn(CreatureSpawnEvent e) {
        if (!enabled || ignored.contains(e.getSpawnReason())) return;
        LivingEntity spawned = e.getEntity();
        if (spawned instanceof ArmorStand) return;

        Chunk chunk = spawned.getLocation().getChunk();
        int total = 0;
        int same = 0;
        for (Entity en : chunk.getEntities()) {
            if (en instanceof LivingEntity && !(en instanceof Player) && !(en instanceof ArmorStand)) {
                total++;
                if (en.getType() == spawned.getType()) same++;
            }
        }
        if (total >= maxMobs || same >= maxSame) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onItemSpawn(ItemSpawnEvent e) {
        if (!enabled) return;
        Chunk chunk = e.getLocation().getChunk();
        int items = 0;
        for (Entity en : chunk.getEntities()) {
            if (en instanceof Item) items++;
        }
        if (items >= maxItems) {
            e.setCancelled(true);
        }
    }
}
