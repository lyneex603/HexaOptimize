package ru.hexatime.optimizer;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public final class HexaOptimizer extends JavaPlugin implements CommandExecutor, TabCompleter {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private ItemCleaner cleaner;
    private SpawnLimiter limiter;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        cleaner = new ItemCleaner(this);
        limiter = new SpawnLimiter(this);
        getServer().getPluginManager().registerEvents(limiter, this);

        for (String name : List.of("lagcheck", "hexaopt")) {
            PluginCommand pc = getCommand(name);
            if (pc != null) {
                pc.setExecutor(this);
                pc.setTabCompleter(this);
            }
        }
        apply();
    }

    @Override
    public void onDisable() {
        if (cleaner != null) cleaner.stop();
    }

    private void apply() {
        reloadConfig();
        limiter.load();
        cleaner.restart();
        applyBorder();
    }

    private void applyBorder() {
        if (!getConfig().getBoolean("world-border.enabled", false)) return;
        ConfigurationSection sec = getConfig().getConfigurationSection("world-border.worlds");
        if (sec == null) return;
        for (String name : sec.getKeys(false)) {
            World w = Bukkit.getWorld(name);
            if (w == null) continue;
            WorldBorder b = w.getWorldBorder();
            b.setCenter(0, 0);
            b.setSize(sec.getDouble(name) * 2);
        }
    }

    // ---------- сообщения ----------

    Component text(String key, String... kv) {
        String raw = getConfig().getString("prefix", "") + getConfig().getString("messages." + key, key);
        for (int i = 0; i + 1 < kv.length; i += 2) {
            raw = raw.replace("{" + kv[i] + "}", kv[i + 1]);
        }
        return MM.deserialize(raw);
    }

    void broadcast(String key, String... kv) {
        Bukkit.broadcast(text(key, kv));
    }

    // ---------- команды ----------

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (cmd.getName().equalsIgnoreCase("lagcheck")) {
            lag(s, a.length > 0 && a[0].equalsIgnoreCase("chunks"));
            return true;
        }
        if (!s.hasPermission("hexaoptimizer.admin")) {
            s.sendMessage(text("no-permission"));
            return true;
        }
        if (a.length == 0) {
            s.sendMessage(MM.deserialize("<gray>/hexaopt reload | clear</gray>"));
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                apply();
                s.sendMessage(text("reloaded"));
            }
            case "clear" -> {
                int n = cleaner.clearNow();
                broadcast("cleared", "count", String.valueOf(n));
            }
            default -> s.sendMessage(MM.deserialize("<gray>/hexaopt reload | clear</gray>"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length != 1) return List.of();
        if (cmd.getName().equalsIgnoreCase("lagcheck")) return List.of("chunks");
        return List.of("reload", "clear");
    }

    private static String fmt(double v) {
        return String.format(Locale.US, "%.1f", Math.min(v, 20.0));
    }

    private void lag(CommandSender s, boolean chunks) {
        double[] t = Bukkit.getTPS();
        double mspt = Bukkit.getAverageTickTime();
        Runtime r = Runtime.getRuntime();
        long max = r.maxMemory() / 1048576;
        long used = (r.totalMemory() - r.freeMemory()) / 1048576;

        s.sendMessage(MM.deserialize("<gold>TPS:</gold> <white>" + fmt(t[0]) + "</white> <gray>(5м: "
                + fmt(t[1]) + ", 15м: " + fmt(t[2]) + ")</gray>"));
        s.sendMessage(MM.deserialize("<gold>MSPT:</gold> <white>" + String.format(Locale.US, "%.1f", mspt) + "</white>"));
        s.sendMessage(MM.deserialize("<gold>Память:</gold> <white>" + used + " / " + max + " МБ</white>"));

        for (World w : Bukkit.getWorlds()) {
            s.sendMessage(MM.deserialize("<gray>" + w.getName() + ":</gray> чанков <white>"
                    + w.getLoadedChunks().length + "</white>, сущностей <white>" + w.getEntities().size() + "</white>"));
        }

        if (chunks) {
            record Row(String world, int x, int z, int n) {}
            List<Row> rows = new ArrayList<>();
            for (World w : Bukkit.getWorlds()) {
                for (Chunk c : w.getLoadedChunks()) {
                    rows.add(new Row(w.getName(), c.getX() * 16, c.getZ() * 16, c.getEntities().length));
                }
            }
            rows.sort(Comparator.comparingInt(Row::n).reversed());
            s.sendMessage(MM.deserialize("<gold>Самые нагруженные чанки:</gold>"));
            for (int i = 0; i < Math.min(5, rows.size()); i++) {
                Row row = rows.get(i);
                s.sendMessage(MM.deserialize("<gray>" + row.world() + " x=" + row.x() + " z=" + row.z()
                        + "</gray> — <white>" + row.n() + "</white>"));
            }
        } else {
            s.sendMessage(MM.deserialize("<dark_gray>/lagcheck chunks — топ чанков по сущностям</dark_gray>"));
        }
    }
}
